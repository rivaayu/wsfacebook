/**
 * @(#)facebook2.java
 *
 * facebook2 application
 *
 * @author 
 * @version 1.00 2017/6/13
 */
 
public class facebook2 {
    
    public static void main(String[] args) {
    	
    	// TODO, add your application code
    	System.out.println("Hello World!");
    }
}
